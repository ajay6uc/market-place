// **********************************************************
// Copyright (c) Cengage Learning 2010 - All rights reserved
// **********************************************************
package com.marketplace.shared.common.framework.web;

/**
 * Resource layer marker interface.
 * 
 * @author jmalkan
 * 
 * @version $Revision$
 * 
 * Created on Nov 8, 2010
 */
public interface Resource {
    //This is a marker interface.
}
